package comp.andro.dialog;

import android.R.layout;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class DialogBoxActivity extends Activity {
	Button but;
	public static final int cont=1;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        but=(Button)findViewById(R.id.button1);
        
        but.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			   showDialog(cont);	
			}
		});
    }
    
    protected Dialog onCreateDialog(int id)
    {
    	AlertDialog dialog = null;
    	AlertDialog.Builder builder=null;
    	builder =new AlertDialog.Builder(this);
    
       LayoutInflater layoutInflater =null;       
       layoutInflater= (LayoutInflater)this.getSystemService(LAYOUT_INFLATER_SERVICE);
       View customLayout =null;
       
       switch(id){
       case 1:
               customLayout= layoutInflater.inflate(R.layout.saveloc,(ViewGroup)findViewById(R.id.save)); 
               
               TextView textviewDisclaimer=(TextView)customLayout.findViewById(R.id.save);
               
               textviewDisclaimer.setText("Do you really want to switch another activity:");
               builder.setView(customLayout);
               builder.setTitle("COnformation");
               builder.setCancelable(false);
               
               builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					startActivity(new Intent(getBaseContext(),second.class));
				}
			});
               
               builder.setPositiveButton("Cancle", new DialogInterface.OnClickListener() {
   				
   				public void onClick(DialogInterface dialog, int which) {
   					// TODO Auto-generated method stub
   					
   				}
   			});
               dialog =builder.create();
               
              break;
              
			};
			 return dialog;
       }
    }

