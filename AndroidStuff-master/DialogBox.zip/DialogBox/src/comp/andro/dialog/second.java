package comp.andro.dialog;

import android.app.Activity;
import android.os.Bundle;

public class second extends Activity{
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
    
}
}