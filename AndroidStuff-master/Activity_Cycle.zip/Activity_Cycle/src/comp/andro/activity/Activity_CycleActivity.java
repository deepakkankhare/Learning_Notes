package comp.andro.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

public class Activity_CycleActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
       
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "My First Android App.", Toast.LENGTH_LONG).show();
        Toast.makeText(getBaseContext(), "Cycle Create",Toast.LENGTH_LONG).show();
    }
    
    @Override
    protected void onStart()
    {
    	super.onStart();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Start",Toast.LENGTH_LONG).show();
    }
   
    @Override
    protected void onPause()
    {
    	super.onPause();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Pause..!",Toast.LENGTH_LONG).show();
    }
   
    @Override
    protected void onRestart()
    {
    	super.onRestart();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Restart",Toast.LENGTH_LONG).show();
    }
   
    @Override
    protected void onResume()
    {
    	super.onResume();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Resume",Toast.LENGTH_LONG).show();
    }
    
    @Override
    protected void onStop()
    {
    	super.onStop();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Stop",Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onDestroy()
    {
    	super.onDestroy();
        setContentView(R.layout.main);
        Toast.makeText(getBaseContext(), "Cycle Destroy",Toast.LENGTH_LONG).show();
    }
   
   
}