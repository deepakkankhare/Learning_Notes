package com.android.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;



public class TempAdapter
{
	public static final String TA_ITEMCODE = "_id";
	public static final String TA_NAME = "item_name";
	public static final String TA_PRICE = "price";
	public static final String TA_SPCREQ = "req";
	public static final String TA_QNT = "qnt";
	public static final String TA_SPICY = "spicy";
	private static final String TAG = "CDBAdapter";
	private static final String DATABASE_NAME = "TEMP";
	private static final String DATABASE_TABLE = "TEMPO";
	private static final int DATABASE_VERSION = 3;
	private static final String TA_CREATE ="create table TEMPO(_id integer,item_name text not null, price integer not null,req text,qnt integer not null,spicy text);";
	//private static final String MC_INSERT ="insert into temptable values(1"+"'x',1,'s',3,'v');";
			
	private final Context context;
	private DatabaseHelper DBHelper;
	public SQLiteDatabase ta;
	
	public TempAdapter(Context ctx)
	{
	this.context = ctx;
	DBHelper = new DatabaseHelper(ctx);
	//System.out.println("IN CONSTRUCTOR");
	}
	public static class DatabaseHelper extends SQLiteOpenHelper
	{
	   DatabaseHelper(Context context)
	   {
	     super(context, DATABASE_NAME, null, DATABASE_VERSION);
	     System.out.println("IN DBHELPER");
	   }
	   
	   @Override
	   public void onUpgrade(SQLiteDatabase ta, int oldVersion, int newVersion)
	   {
	     Log.w(TAG, "Upgrading database from version " + oldVersion + " to "+ newVersion + ", which will destroy all old data");
	     ta.execSQL("DROP TABLE IF EXISTS kopa");
	
	     onCreate(ta);
	   }

	@Override
	public void onCreate(SQLiteDatabase ta)
	   {
	     try 
	     {
	    	 System.out.println("TEMPORARY DATABASE CREATED SUCCESSSS");
	    	 ta.execSQL(TA_CREATE);	       
	     } 
	     catch (SQLException e) 
	     {
	    	 System.out.println("EXception occured tempadapter---->"+e.toString());
	     }
	   } }
	
	//---opens the database---
	public TempAdapter open() throws SQLException
	{
	ta = DBHelper.getWritableDatabase();
	return this;
	}
	//---closes the database---
	public void close()
	{
	DBHelper.close();
	}
	public long insertDetails(int _id,String item_name, Integer price,String req,Integer qnt,String spicy)
	{
	ContentValues initialValues = new ContentValues();
	initialValues.put(TA_ITEMCODE, _id);
	initialValues.put(TA_NAME, item_name);
	initialValues.put(TA_PRICE, price);
	initialValues.put(TA_SPCREQ, req);
	initialValues.put(TA_QNT, qnt);
	initialValues.put(TA_SPICY, spicy);
	return ta.insert(DATABASE_TABLE, null, initialValues);
	}
	public Cursor getAllContacts()
	{
		return ta.query(DATABASE_TABLE, new String[] {TA_ITEMCODE,TA_NAME,TA_PRICE,TA_SPCREQ,TA_QNT,TA_SPICY}, null, null, null, null,null);
	}
	public void delete()
	{
		ta.execSQL("DELETE FROM kopa");
	}
	public boolean deleteContact(String name1)
	{
	return ta.delete(DATABASE_TABLE, TA_NAME + "=" + name1, null) > 0;
	}
	public boolean updateContact(Integer code,Integer qnt,Integer price)
	{
	ContentValues args = new ContentValues();
	args.put(TA_QNT, qnt);
	return ta.update(DATABASE_TABLE, args, TA_ITEMCODE + "=" + code, null) > 0;
	}
}
