package com.android.sqlite;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

public class SqliteActivity extends Activity {
	TempAdapter ta=new TempAdapter(this);
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ta.open();
        ta.delete();
       long l= ta.insertDetails(1, "soup",50, "gravy", 5, "yes");
       if(l>=1)
       {
    	   Toast.makeText(getBaseContext(), "data inserted successfully", Toast.LENGTH_LONG).show();
       }
       else
       {
    	   Toast.makeText(getBaseContext(), "error inserting records", Toast.LENGTH_LONG).show(); 
       }
       Display();
       ta.close();
    }
   public void Display()
    {
    	Cursor c=ta.getAllContacts();
    	if(c.moveToNext())
    	{
    		do
    		{
    			Toast.makeText(getBaseContext(), "Id:"+c.getString(0)
    					+"\nName:"+c.getString(1)
    					+"\nPrice:"+c.getString(2)
    					+"\nSpecial Req:"+c.getString(3)
    					+"\nQuantity:"+c.getString(4)
    					+"\nSpicy:"+c.getString(1), Toast.LENGTH_LONG).show();
    		}while(c.moveToFirst());
    	}
    }
}