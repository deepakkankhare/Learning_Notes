package com.android.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class CurrentAdapter {
	public static final String TA_ITEMCODE = "_id";
	public static final String TA_ITEMTYPE = "itemtype";
	public static final String TA_NAME = "item_name";
	public static final String TA_PRICE = "price";
	public static final String TA_SPCREQ = "req";
	public static final String TA_QNT = "qnt";
	public static final String TA_SPICY = "spicy";
	private static final String TAG = "CDBAdapter";
	private static final String DATABASE_NAME = "cu";
	private static final String DATABASE_TABLE = "cord";
	private static final int DATABASE_VERSION = 4;
	private static final String TA_CREATE ="create table cord(_id integer,item_name text not null, price integer not null,req text,qnt integer,spicy text,itemtype text not null);";
	//private static final String MC_INSERT ="insert into temptable values(1"+"'x',1,'s',3,'v');";
			
	private final Context context;
	private DatabaseHelper DBHelper;
	public SQLiteDatabase ta;
	
	public CurrentAdapter(Context ctx)
	{
	this.context = ctx;
	DBHelper = new DatabaseHelper(context);
	System.out.println("IN CONSTRUCTOR");
	}
	public static class DatabaseHelper extends SQLiteOpenHelper
	{
	   DatabaseHelper(Context context)
	   {
	     super(context, DATABASE_NAME, null, DATABASE_VERSION);
	     System.out.println("IN DBHELPER");
	   }

		@Override
		public void onCreate(SQLiteDatabase ta)
		   {
		     try 
		     {
		    	 System.out.println("TEMPORARY DATABASE CREATED SUCCESSSS");
		    	 ta.execSQL(TA_CREATE);	       
		     } 
		     catch (SQLException e) 
		     {
		    	 System.out.println("EXception occured tempadapter---->"+e.toString());
		     }
		   }	   
	   @Override
	   public void onUpgrade(SQLiteDatabase ta, int oldVersion, int newVersion)
	   {
	     Log.w(TAG, "Upgrading database from version " + oldVersion + " to "+ newVersion + ", which will destroy all old data");
	     ta.execSQL("DROP TABLE IF EXISTS TEMP");
	
	     onCreate(ta);
	   }
 }
	
	//---opens the database---
	public CurrentAdapter open() throws SQLException
	{
	ta = DBHelper.getWritableDatabase();
	return this;
	}
	//---closes the database---
	public void close()
	{
	DBHelper.close();
	}
	public long insertDetails(int _id,String item_name, int price,String req,int qnt,String spicy,String itm)
	{
	ContentValues initialValues = new ContentValues();
	initialValues.put(TA_ITEMCODE, _id);
	initialValues.put(TA_NAME, item_name);
	initialValues.put(TA_PRICE, price);
	initialValues.put(TA_ITEMTYPE, itm);
	initialValues.put(TA_SPCREQ, req);
	initialValues.put(TA_QNT, qnt);
	initialValues.put(TA_SPICY, spicy);
	return ta.insert(DATABASE_TABLE, null, initialValues);
	}
	public Cursor getAllContacts()
	{
		return ta.query(DATABASE_TABLE, new String[] {TA_ITEMCODE,TA_NAME,TA_PRICE,TA_SPCREQ,TA_QNT,TA_SPICY,TA_ITEMTYPE}, null, null, null, null,null);
	}
	public void delete()
	{
		ta.execSQL("DELETE FROM cord");
	}
	public boolean deleteContact(String name1)
	{
	return ta.delete(DATABASE_TABLE, TA_NAME + "=" + name1, null) > 0;
	}
	
	public boolean update(int itemcode,String item_name, int price,String req,int qnt,String spicy,String itm){
		ContentValues initialValues=new ContentValues();
		initialValues.put(TA_ITEMCODE, itemcode);
		initialValues.put(TA_NAME, item_name);
		initialValues.put(TA_PRICE, price);
		initialValues.put(TA_ITEMTYPE, itm);
		initialValues.put(TA_SPCREQ, req);
		initialValues.put(TA_QNT, qnt);
		initialValues.put(TA_SPICY, spicy);
		Cursor mCursor = ta.query(DATABASE_TABLE, new String[] {TA_ITEMCODE,TA_NAME,TA_PRICE,TA_SPCREQ,TA_QNT,TA_SPICY,TA_ITEMTYPE},null, null, null, null, null);
		/*int rowId=-1;
		mCursor.moveToFirst();
		do{
			if(Integer.parseInt(mCursor.getString(0))==itemcode)
				rowId=Integer.parseInt(mCursor.getString(0));
		}while(mCursor.moveToNext());
		
		mCursor.close();*/
		
		return ta.update(DATABASE_TABLE, initialValues,TA_ITEMCODE + "=" + itemcode, null) > 0;
	}
	public int getQuantity(int item_code){
		//ContentValues initialValues=new ContentValues();
		
		Cursor mCursor = ta.query(DATABASE_TABLE, new String[] {TA_ITEMCODE,TA_NAME,TA_PRICE,TA_SPCREQ,TA_QNT,TA_SPICY,TA_ITEMTYPE},null, null, null, null, null);
		int rowId=-1;
		mCursor.moveToFirst();
		do{
			if(Integer.parseInt(mCursor.getString(0))==item_code)
				rowId=Integer.parseInt(mCursor.getString(4));
		}while(mCursor.moveToNext());
		
		mCursor.close();
		
		return rowId;
	}
	
	public boolean getAvailable(int itemcode)
	{
		Cursor mCursor = ta.query(DATABASE_TABLE, new String[] {TA_ITEMCODE,TA_NAME,TA_PRICE,TA_SPCREQ,TA_QNT,TA_SPICY,TA_ITEMTYPE},null, null, null, null, null);
		boolean rowId=false;
		if(mCursor.moveToFirst())
		{
		do{
			if(Integer.parseInt(mCursor.getString(0))==itemcode)
			rowId=true;
		}while(mCursor.moveToNext());
		mCursor.close();
		}
		return rowId;
	}
	/*public boolean deleteItem(Integer code)
	{
	return ta.delete(DATABASE_TABLE, TA_ITEMCODE + "=" + code, null) > 0;
	}*/
	/*public boolean updateContact(Integer code,Integer qnt,Integer price)
	{
	ContentValues args = new ContentValues();
	args.put(TA_QNT, qnt);
	return ta.update(DATABASE_TABLE, args, TA_ITEMCODE + "=" + code, null) > 0;
	}*/

}
