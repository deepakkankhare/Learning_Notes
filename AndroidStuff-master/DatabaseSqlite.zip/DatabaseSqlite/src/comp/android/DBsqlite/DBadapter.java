package comp.android.DBsqlite;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBadapter 
{

	 public static final String User_name="uname";
	 public static final String FVT_GAME="fvtgame";
	 public static final String YOUR_Ideol="ideol";
	 public static final String FVT_Movie="movie";
	 public static final String Life_Aim="aim";
	 private static final String Database_Name="frndDB";
	 private static final String Database_info="DBinfo";
	 private static final int  Database_Version=1;
	 private static final String Database_CERATE="Create table frnddb(uname text not null,fvtgame text not null,ideol text not null,movie text not null,aim text not null)";
     private final Context context;
     private DatabaseHelper DBHelper;
 	private SQLiteDatabase db;

 
 	public DBadapter(Context con)
 	{
 		this.context=con;
 		DBHelper =new DatabaseHelper(context);
 		
 	}
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		public DatabaseHelper(Context context) {
			super(context,Database_Name,null,Database_Version);
			// TODO Auto-generated constructor stub
		}
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			try
			{
				db.execSQL(Database_CERATE);
			}catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		@Override
		public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion)
		{
//			Log.w(TAG,"Upgrading database from version"+oldVersion+"to"
//					+newVersion+",which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS contacts");
			
			onCreate(db);
		}
	}
	//---opens the database----
	public DBadapter open() throws SQLException
	{
		db=DBHelper.getWritableDatabase();
		return this;
	}
			
		//---closes the database---
	public void close()
	{
		DBHelper.close();
	}
	//inserts into database
	public long insertDetails(String name,String game,String movie,String ideol,String aim)
	{
		ContentValues initialValues = new ContentValues();
	//	initialValues.put(EMPLOYEE_ID,id);
		initialValues.put(User_name, name);
		initialValues.put(FVT_GAME, game);
		initialValues.put(FVT_Movie, movie);
		initialValues.put(YOUR_Ideol, ideol);
		initialValues.put(Life_Aim,aim);
		
		return db.insert(Database_info, null, initialValues);
	}
	
	//----deletes a particular contact---
//	public boolean deleteip(String rowId)
//	{
//		return db.delete(DATABASE_TABLE, KEY_IPADDRESS+"="+rowId, null)>0;
//	}
	
	//------retrives all clients----
	public Cursor getEmployeeDetails()
	{
		return db.query(Database_info, new String[]{User_name,FVT_GAME,FVT_Movie,YOUR_Ideol,Life_Aim},null, null, null,null, null);
	}
	//retrieve a particular contact
//	public Cursor getClient(String rowId) throws SQLException
//	{
//		Cursor mCursor=
//				db.query(DATABASE_TABLE, new String[]{KEY_IPADDRESS},null, null, null,null, null);
//		if(mCursor!=null){
//			mCursor.moveToFirst();
//		}
//		return mCursor;
//	}
	
	
	//-----delete all contacts-----
	public void delete()
	{
	
		db.execSQL("DELETE FROM employeedetails");
	}

}
