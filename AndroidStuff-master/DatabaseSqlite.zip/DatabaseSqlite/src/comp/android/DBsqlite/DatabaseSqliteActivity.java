package comp.android.DBsqlite;

import java.security.PublicKey;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DatabaseSqliteActivity extends Activity 
{
EditText uname,fvtgame,ideol,movie,aim;
Button insert,Display;
DBadapter db = new DBadapter(this);
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        uname=(EditText)findViewById(R.id.editText1);
        fvtgame=(EditText)findViewById(R.id.editText2);
        ideol=(EditText)findViewById(R.id.editText3);
        movie=(EditText)findViewById(R.id.editText4);
        aim=(EditText)findViewById(R.id.editText5);
        insert=(Button)findViewById(R.id.button1);
        Display=(Button)findViewById(R.id.button1);
        
        
        insert.setOnClickListener(new OnClickListener() 
        {
		 public void onClick(View v) 
		 {
			 
			// TODO Auto-generated method stub
			 if(uname.getText().toString().equals("")||fvtgame.getText().toString().equals("")||ideol.getText().toString().equals("")||movie.getText().toString().equals("")||aim.getText().toString().equals(""))
			 {
					Toast.makeText(getBaseContext(), "Pls fill in all the details", Toast.LENGTH_LONG).show();
			 }
			 
			 
			 else{ 
				   String textuname,textgame,textideol,textmov,textaim;
				   textuname=uname.getText().toString();
				   textgame=fvtgame.getText().toString();
				   textideol=ideol.getText().toString();
				   textmov=movie.getText().toString();
				   textaim=aim.getText().toString();
				   
				   db.open();
				   
				   long i= db.insertinfo(textuname,textgame,textideol,textmov,textaim);
				   if(i>0)
				   {
					   Toast.makeText(getBaseContext(), "Data Inserted Successfully..!Thank you",Toast.LENGTH_LONG).show();
				   }
				  else 
			          {
				       Toast.makeText(getBaseContext(), "Error in Fill info in Database..", Toast.LENGTH_LONG).show(); 
			          }
			 db.close();
			}
         });
        
        public void display(Cursor c)
        {
        	if(c.moveToFirst()){
        		do {
					Toast.makeText(getBaseContext(), "1:Your Name:"+c.getString(0)+
							                         "2:Favorite Game:"+c.getString(1)+
							                         "3:Your Ideol:"+c.getString(2)+
							                         "4:Favorite Movie:"+c.getString(3)+
							                         "5:AIM of Life:"+c.getString(4),Toast.LENGTH_LONG).show();
				} while (c.moveToNext());
        	}
        }
        
        
    
