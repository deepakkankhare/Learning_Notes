package comp.andro.sqldb;




import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;




public class Adapter
{
	//public static final String  
	public static final  String student_name= "sname";
	public static final  String student_roll= "sRoll_No";
	public static final  String student_Branch= "sBranch";
	public static final  String student_year= "syear";
	private static final String DATABASE_NAME = "sMydata";
	private static final String DATABASE_TABLE = "student";
	private static final int DATABASE_VERSION = 3;
	private static final String TAG = "CDBAdapter";
	
	private static final String MC_CREATE ="create table student ("
			+ "sRoll_No integer not null,sBranch text not null,sname text not null,syear integer not null);";
	//private static final String Roll_No = null;
//	private static final String Branch = null;
	
	private  Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase dab;
	
	
	public  Adapter(Context ctx)
	{
	this.context = ctx;
	DBHelper = new DatabaseHelper(context);
	
	}
	
	public static class DatabaseHelper extends SQLiteOpenHelper
	{
	   DatabaseHelper(Context context)
	   {
	     super(context, DATABASE_NAME, null, DATABASE_VERSION);
	   }
	   @Override
	   public void onCreate(SQLiteDatabase dab)
	   {
	     try 
	     {
	       dab.execSQL(MC_CREATE);
	       System.out.println("In create");
	     } 
	     catch (SQLException e) 
	     {
	         e.printStackTrace();
	     }
	   }
	   @Override
	   public void onUpgrade(SQLiteDatabase dab, int oldVersion, int newVersion)
	   {
	     Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
	     + newVersion + ", which will destroy all old data");
	     dab.execSQL("DROP TABLE IF EXISTS student");
	
	     onCreate(dab);
	   }
	 }
	//---opens the database---
	public Adapter open() throws SQLException
	{
	dab = DBHelper.getWritableDatabase();
	return this;
	}
	
	public void close()
	{
	DBHelper.close();
	}
	public long insertDetails( String name,Integer Roll_No,String Branch,Integer year)
	{
	ContentValues initialValues = new ContentValues();

	
	initialValues.put(student_roll,Roll_No);
	initialValues.put(student_Branch, Branch);
	initialValues.put(student_name,name);
	initialValues.put(student_year,year);	
	return dab.insert(DATABASE_TABLE, null, initialValues);
	}
	public Cursor getAllContacts()
	{
	return dab.query(DATABASE_TABLE, new String[] {student_name,
			student_roll,student_Branch,student_year}, null, null, null, null, null);
	}
	public void delete()
	{
		dab.execSQL("DELETE FROM student");
	}
	
	public Boolean updaterecord(String name,Integer rollno, String branch,Integer year)
	{
		ContentValues args =new ContentValues();
		args.put(student_name,name);
		args.put(student_Branch,branch);
		args.put(student_year,year);
		
		
		return dab.update(DATABASE_TABLE,args,student_roll+ "=" +rollno, null)>0;
		
		
	
		
	}
}