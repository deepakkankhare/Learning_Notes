package comp.andro.sqldb;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SQLDB extends Activity
{
	Adapter dba=new  Adapter(this);
	Button button1;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        button1=(Button)findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() 
        {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dba.open();
				//dba.delete();
				
			long l=dba.insertDetails("Deepak", 29, "Computer",4);
			long l1=dba.insertDetails("Prasad", 70, "I.T",4);
			long l2=dba.insertDetails("Abhishek", 10, "Computer",4);	
			if(l2>=1)
				{
					Toast.makeText(getBaseContext(),"Data inserted successfully",Toast.LENGTH_LONG).show();
				}
				else
				{
					Toast.makeText(getBaseContext(),"Error inserting data",Toast.LENGTH_LONG).show();
				}
		Cursor c=dba.getAllContacts();
				Display(c);
				boolean update=dba.updaterecord("Mayur", 29, "IT", 4);
				if(update)
				{
					Toast.makeText(getBaseContext(), "Updated successfully",Toast.LENGTH_LONG).show();
				}
				else
				{
					Toast.makeText(getBaseContext(), "error updating values",Toast.LENGTH_LONG).show();
				}
				dba.close();
				
			}
		});
        
    }
    public void Display(Cursor c)
    {
    	if(c.moveToFirst())
    	{
    		do
    		{
    			Toast.makeText(getBaseContext(),
    					"\nStudent_Name:"+c.getString(0)+
    					"\nRoll_No:"+c.getString(1)+
    					"\nStudent_Branch:"+c.getString(2)+
    					"\nPresent year:"+c.getString(3)
    					, Toast.LENGTH_LONG).show();
    		}while(c.moveToNext());
    	}
    }
}