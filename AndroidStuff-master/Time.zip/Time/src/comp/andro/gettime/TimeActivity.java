package comp.andro.gettime;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class TimeActivity extends Activity {
    /** Called when the activity is first created. */
	DatePicker datePicker;
	TimePicker timePicker;
	Button button1;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        timePicker=(TimePicker)findViewById(R.id.timePicker1);
        
       button1.setOnClickListener(new View.OnClickListener() {
		
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			Toast.makeText(getBaseContext(),"Ready to change time", Toast.LENGTH_SHORT).show();
			
		}
	});
       
        
        //date=(DatePicker)findViewById(R.Id.date);
        //time=(TimePicker)findViewById(R.id.time);
        
    }
}