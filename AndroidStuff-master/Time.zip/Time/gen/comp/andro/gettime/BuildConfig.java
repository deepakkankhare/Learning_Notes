/** Automatically generated file. DO NOT MODIFY */
package comp.andro.gettime;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}