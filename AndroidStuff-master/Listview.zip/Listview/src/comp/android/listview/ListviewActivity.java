package comp.android.listview;


import android.R.layout;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ListviewActivity extends Activity {
	ListView list;
    /** Called when the activity is first created. */
	String[] branch = new String[] {"Computer","Electrical","E&TC","Mechanical"};
	@Override
    
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        list =(ListView)findViewById(R.id.listView1);
    list.setAdapter(new ArrayAdapter<String>(getBaseContext(), layout.simple_expandable_list_item_1,branch));
    
	list.setOnItemClickListener(new OnItemClickListener() {

		public void onItemClick(AdapterView<?> arg0, View arg1, int pos,
				long arg3) {
			// TODO Auto-generated method stub
			Toast.makeText(getBaseContext(), ""+branch[pos], Toast.LENGTH_LONG).show();
			
			if(branch[pos].equals("Computer"))
			{
			startActivity(new Intent(getBaseContext(),computerdetails.class));	
			}
			else if(branch[pos].equals("Electrical"))
			{
				startActivity(new Intent(getBaseContext(),electricaldetails.class));	
			}
			else if(branch[pos].equals("E&TC"))
			{
			startActivity(new Intent(getBaseContext(),eandtcdetails.class));	
			}
			else if(branch[pos].equals("Mechanical"))
			{
				startActivity(new Intent(getBaseContext(),mechanicaldetails.class));	
			}
		}
	});
	
	}
}