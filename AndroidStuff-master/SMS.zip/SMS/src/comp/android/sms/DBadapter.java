package comp.android.sms;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DBadapter  {	
	public static final  String reciver_no= "mob_No";
	public static final  String message= "msg";
	private static final String DATABASE_NAME = "dbsms";
	private static final String DATABASE_TABLE = "contacts";
	private static final int DATABASE_VERSION = 1;
	private static final String TAG = "CDBAdapter";
	
	private static final String SENDSMS ="create table contacts ("
			+ "mob_No text not null);";
	private static final String mob_No = null;
	private static final String msg = null;
	
	private  Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase dab;
	
	
	public DBadapter(Context ctx)
	{
	this.context = ctx;
	DBHelper = new DatabaseHelper(context);
	
	}
	public static class DatabaseHelper extends SQLiteOpenHelper
	{
	   DatabaseHelper(Context context)
	   {
	     super(context, DATABASE_NAME, null, DATABASE_VERSION);
	   }
	   @Override
	   public void onCreate(SQLiteDatabase dab)
	   {
	     try 
	     {
	       dab.execSQL(SENDSMS);
	     } 
	     catch (SQLException e) 
	     {
	         e.printStackTrace();
	     }
	   }
	   @Override
	   public void onUpgrade(SQLiteDatabase dab, int oldVersion, int newVersion)
	   {
	     Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
	     + newVersion + ", which will destroy all old data");
	     dab.execSQL("DROP TABLE IF EXISTS details");
	
	     onCreate(dab);
	   }
	 }
	//---opens the database---
	public DBadapter open() throws SQLException
	{
	dab = DBHelper.getWritableDatabase();
	return this;
	}
	
	public void close()
	{
	DBHelper.close();
	}
	public long insertDetails(String name)
	{
	ContentValues initialValues = new ContentValues();

	//String name = null;
	//initialValues.put(MC_ITEMCODE, _id);
	//initialValues.put(MC_NAME, item_name);
	
	initialValues.put(reciver_no,name);
	
		
	return dab.insert(DATABASE_TABLE, null, initialValues);
	}
	public Cursor getAllContacts()
	{
	return dab.query(DATABASE_TABLE, new String[] {
			reciver_no}, null, null,null,null,null);
	}
	public void delete()
	{
		dab.execSQL("DELETE FROM contacts");
	}
	
}


