package comp.android.sms;

import android.app.Activity;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SMSActivity extends Activity {
	
	
	Button b1,b2;
	TextView t1,t2;
	DBadapter db=new DBadapter(this);
	
		
		
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        b1=(Button)findViewById(R.id.button1);
        b2=(Button)findViewById(R.id.button2);
        t1=(TextView)findViewById(R.id.editText1);
        t2=(TextView)findViewById(R.id.editText2);
        
        
        
        b1.setOnClickListener(new OnClickListener() 
        {
        	
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(t1.getText().equals(""))
				{
					Toast.makeText(getBaseContext(), "Please enter number", Toast.LENGTH_LONG).show();
					
				}	
				else
				{
					db.open();
					long i= db.insertDetails(t1.getText().toString());
					db.close();
					if(i>0){
						Toast.makeText(getBaseContext(), "Number added", Toast.LENGTH_LONG).show();
					}
					else{
						Toast.makeText(getBaseContext(), "Error adding number", Toast.LENGTH_LONG).show();
					}
				}
			}
		});
        
        b2.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			if(t2.getText().equals(""))
			{
				Toast.makeText(getBaseContext(), "Please write a message",Toast.LENGTH_LONG).show();
			}
			else
			{
				SmsManager sms=SmsManager.getDefault();
				db.open();
				Cursor c=db.getAllContacts();
				if(c.getCount()>0){
					if(c.moveToFirst()){
						do{
					        sms.sendTextMessage(c.getString(0), null, t2.getText().toString(),null, null);
						}while(c.moveToNext());
					}
				}
				else{
					Toast.makeText(getBaseContext(), "No nuber selected", Toast.LENGTH_LONG).show();
				}
			}
			}
		});
        
    }
}