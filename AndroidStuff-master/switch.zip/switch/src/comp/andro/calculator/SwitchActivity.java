package comp.andro.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class SwitchActivity extends Activity {
	
	Button Perform;
	RadioButton add,sub,mul,div;
	EditText input1,input2,result;
	
  
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    
    input1=(EditText)findViewById(R.id.input1);
    input2=(EditText)findViewById(R.id.input2);
    result=(EditText)findViewById(R.id.Result);
    add=(RadioButton)findViewById(R.id.add);
    sub=(RadioButton)findViewById(R.id.sub);
    mul=(RadioButton)findViewById(R.id.mul);
    div=(RadioButton)findViewById(R.id.div);
    Perform=(Button)findViewById(R.id.Perform);
    
    Perform.setOnClickListener(new OnClickListener() {
		
		public void onClick(View v) {
			int a=Integer.parseInt(input1.getText().toString());
			int b=Integer.parseInt(input2.getText().toString());
            int c;
			
			if(add.isChecked())
			{
				c=a+b;
				
			}
			else if (sub.isChecked()) {
				c=a-b;
			}
			else if (mul.isChecked()) {
				c=a*b;
			}
			else if (div.isChecked()){
				c=a/b;
			}
			else{
				Toast.makeText(getBaseContext(), "Select operation",Toast.LENGTH_LONG).show();
			}
			// TODO Auto-generated method stub
			
		}
	});
    
    }
    
}