package comp.android.spinner;

import android.app.Activity;
import android.os.Bundle;

public class computerdetails extends Activity 
{
@Override
    
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comp);
    
}
}