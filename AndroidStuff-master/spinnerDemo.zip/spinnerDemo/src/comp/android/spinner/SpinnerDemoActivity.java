package comp.android.spinner;

import comp.android.spinner.computerdetails;

import android.R.layout;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class SpinnerDemoActivity extends Activity {
	Spinner spin;
	String[] branch= new String[] {"COMPUTER","ELECTRICAL","E&TC","MECHANICAL","CIVIL"};
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        spin = (Spinner)findViewById(R.id.spinner1);
        spin.setAdapter(new ArrayAdapter<String>(getBaseContext(),layout.simple_spinner_dropdown_item,branch ));
        
       spin.setOnItemSelectedListener(new OnItemSelectedListener() {

		public void onItemSelected(AdapterView<?> arg0, View arg1, int pos,
				long arg3) {
			// TODO Auto-generated method stub
			Toast.makeText(getBaseContext(),""+branch[pos],Toast.LENGTH_LONG).show();
			if(branch[pos].equals("COMPUTER"))
			{
				startActivity(new Intent(getBaseContext(),computerdetails.class));
			}
			else if(branch[pos].equals("ELECTRICAL"))
			{
				startActivity(new Intent(getBaseContext(),electricaldetails.class));
			}
			else if(branch[pos].equals("E&TC"))
			{
				startActivity(new Intent(getBaseContext(),eandtcdetails.class));
			}
			else if(branch[pos].equals("MECHANICAL"))
			{
				startActivity(new Intent(getBaseContext(),mechanicaldetails.class));
			}
		}

		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
	});
    }
}